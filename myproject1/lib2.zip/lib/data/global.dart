import 'package:shopingpriject/models/user_model.dart';

List<User> userList = [];
late User currentUser;
List<User> listdata = [];
