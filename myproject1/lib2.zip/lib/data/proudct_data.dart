List proudctData=[
  {
    "image": "lib\\assets\\imges\\backgroung_img.jpg",
    "name": "Tourbilin Dold",
    "description": "it is a long established fact that a reader will be distracted by the readable content of a page",
    "price": "\$ 3500",
    "subTotal": 0,
    "count": 0
  },
  {
    "image": "lib\\assets\\imges\\elegant_watch.jpg",
    "name": "Elegant Chronometer",
    "description": "A sleek wristwatch that combines modern design with timeless craftsmanship.",
    "price": "\$ 4750",
    "subTotal": 0,
    "count": 0
  },
  {
    "image": "lib\\assets\\imges\\vintage_camera.jpg",
    "name": "Retro Cam XG2",
    "description": "Capture the essence of the past with this vintage-inspired digital camera.",
    "price": "\$ 890",
    "subTotal": 0,
    "count": 0
  },
  {
    "image": "lib\\assets\\imges\\leather_boots.jpg",
    "name": "Rugged Trailblazers",
    "description": "Durable and stylish, these leather boots are perfect for your next adventure.",
    "price": "\$ 320",
    "subTotal": 0,
    "count": 0
  },
  {
    "image": "lib\\assets\\imges\\smart_speaker.jpg",
    "name": "Smart Echo Base",
    "description": "A smart speaker that blends into your home with its superior sound and voice control.",
    "price": "\$ 199",
    "subTotal": 0,
    "count": 0
  },
  {
    "image": "lib\\assets\\imges\\gourmet_coffee.jpg",
    "name": "Arabica Premium",
    "description": "Experience the deep, rich flavors of freshly ground Arabica beans.",
    "price": "\$ 35",
    "subTotal": 0,
    "count": 0
  },
  {
    "image": "lib\\assets\\imges\\fitness_tracker.jpg",
    "name": "FitBand Advance",
    "description": "Stay ahead of your fitness goals with this next-gen waterproof fitness tracker.",
    "price": "\$ 129",
    "subTotal": 0,
    "count": 0
  }
];
