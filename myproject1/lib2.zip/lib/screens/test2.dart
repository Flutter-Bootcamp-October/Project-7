 /* import 'package:shopingpriject/data/global.dart';
import 'package:shopingpriject/data/user_data.dart';
import 'package:shopingpriject/models/user_model.dart';

void initState() {
    for (var element in userdata) {
      listdata.add(User.fromJson(element));
    }
    super.initState();
  }*/